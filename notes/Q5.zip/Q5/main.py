import utils
import numpy as np

def main():
    #state = [1, 0, 0, 3, 4, 5, 1, 6]
  
    #result_5_1 = utils.steepestAscent(state)

    #result_5_2 = utils.steepestAscentRandomRestart(state)

    totalh = 0
    for i in range(1000):
        totalh += utils.geneticAlgorithm()
        print(i)
    result_5_3 = totalh / 1000 # should be close to 2.33
    return

if __name__=="__main__":
    main()
